// Re-export from the navigation folder for backwards compatibility
export { AdminSidebar } from "./navigation/AdminSidebar";
