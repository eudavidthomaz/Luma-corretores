// Re-export from the navigation folder for backwards compatibility
export { MobileNav } from "./navigation/MobileNav";
