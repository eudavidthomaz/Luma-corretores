-- Limpar dados do workspace anterior (ordem correta para foreign keys)
DELETE FROM story_views;
DELETE FROM story_chapters;
DELETE FROM stories;
DELETE FROM leads;
DELETE FROM profiles;